<?php

/**
 * Class Fruit
 * Permet la representation informatique d'un fruit
 */
class Fruit
{
    private $nom = "Philippe";                    //Attribut
    private $couleur = "Verte";                      //Attribut
}